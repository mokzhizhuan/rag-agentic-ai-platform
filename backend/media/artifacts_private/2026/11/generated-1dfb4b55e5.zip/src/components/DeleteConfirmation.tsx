import { useEffect, useRef } from 'react';
import type { DeleteConfirmationProps } from '../types';

function DeleteConfirmation({
  equipment,
  isOpen,
  onCancel,
  onConfirm,
}: DeleteConfirmationProps) {
  const cancelButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    cancelButtonRef.current?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onCancel();
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onCancel]);

  if (!isOpen || !equipment) {
    return null;
  }

  const handleOverlayClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (event.target === event.currentTarget) {
      onCancel();
    }
  };

  return (
    <div
      className="modal-backdrop"
      role="presentation"
      onMouseDown={handleOverlayClick}
    >
      <div
        className="confirmation-dialog"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="delete-confirmation-title"
        aria-describedby="delete-confirmation-description"
      >
        <div className="dialog-icon" aria-hidden="true">
          !
        </div>

        <div className="dialog-content">
          <h2 id="delete-confirmation-title">Delete equipment?</h2>
          <p id="delete-confirmation-description">
            Are you sure you want to delete{' '}
            <strong>{equipment.name}</strong>? This action cannot be undone.
          </p>

          <div className="dialog-actions">
            <button
              ref={cancelButtonRef}
              type="button"
              className="button button-secondary"
              onClick={onCancel}
            >
              Cancel
            </button>
            <button
              type="button"
              className="button button-danger"
              onClick={onConfirm}
            >
              Delete equipment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DeleteConfirmation;
