import { FormEvent, useEffect, useId, useState } from 'react';
import {
  EquipmentFormProps,
  EquipmentFormValues,
  EquipmentStatus,
} from '../types';

const defaultValues: EquipmentFormValues = {
  name: '',
  category: '',
  serialNumber: '',
  location: '',
  status: 'Available',
  assignedTo: '',
  purchaseDate: '',
  notes: '',
};

type FormErrors = Partial<Record<keyof EquipmentFormValues, string>>;

function getValues(initialValues?: EquipmentFormValues): EquipmentFormValues {
  return initialValues ? { ...initialValues } : { ...defaultValues };
}

export default function EquipmentForm({
  initialValues,
  onSubmit,
  onCancel,
  submitLabel = 'Save equipment',
}: EquipmentFormProps) {
  const [values, setValues] = useState<EquipmentFormValues>(
    getValues(initialValues),
  );
  const [errors, setErrors] = useState<FormErrors>({});
  const formId = useId();

  useEffect(() => {
    setValues(getValues(initialValues));
    setErrors({});
  }, [initialValues]);

  const updateField = <K extends keyof EquipmentFormValues>(
    field: K,
    value: EquipmentFormValues[K],
  ) => {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      if (!current[field]) {
        return current;
      }

      const next = { ...current };
      delete next[field];
      return next;
    });
  };

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};

    if (!values.name.trim()) {
      nextErrors.name = 'Enter an equipment name.';
    }

    if (!values.category.trim()) {
      nextErrors.category = 'Enter a category.';
    }

    if (!values.serialNumber.trim()) {
      nextErrors.serialNumber = 'Enter a serial number.';
    }

    if (!values.location.trim()) {
      nextErrors.location = 'Enter a location.';
    }

    if (!values.purchaseDate) {
      nextErrors.purchaseDate = 'Select a purchase date.';
    }

    return nextErrors;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const nextErrors = validate();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      const firstInvalidField = Object.keys(nextErrors)[0];
      document
        .getElementById(`${formId}-${firstInvalidField}`)
        ?.focus();
      return;
    }

    onSubmit({
      name: values.name.trim(),
      category: values.category.trim(),
      serialNumber: values.serialNumber.trim(),
      location: values.location.trim(),
      status: values.status,
      assignedTo: values.assignedTo.trim(),
      purchaseDate: values.purchaseDate,
      notes: values.notes.trim(),
    });
  };

  const fieldId = (field: keyof EquipmentFormValues) => `${formId}-${field}`;
  const errorId = (field: keyof EquipmentFormValues) =>
    `${fieldId(field)}-error`;

  const describedBy = (field: keyof EquipmentFormValues) =>
    errors[field] ? errorId(field) : undefined;

  return (
    <form className="equipment-form" onSubmit={handleSubmit} noValidate>
      <div className="form-grid">
        <div className="form-field">
          <label htmlFor={fieldId('name')}>
            Equipment name <span aria-hidden="true">*</span>
          </label>
          <input
            id={fieldId('name')}
            name="name"
            type="text"
            value={values.name}
            onChange={(event) => updateField('name', event.target.value)}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={describedBy('name')}
            autoComplete="off"
            required
          />
          {errors.name && (
            <p className="field-error" id={errorId('name')} role="alert">
              {errors.name}
            </p>
          )}
        </div>

        <div className="form-field">
          <label htmlFor={fieldId('category')}>
            Category <span aria-hidden="true">*</span>
          </label>
          <input
            id={fieldId('category')}
            name="category"
            type="text"
            value={values.category}
            onChange={(event) => updateField('category', event.target.value)}
            aria-invalid={Boolean(errors.category)}
            aria-describedby={describedBy('category')}
            placeholder="e.g. Laptop"
            required
          />
          {errors.category && (
            <p className="field-error" id={errorId('category')} role="alert">
              {errors.category}
            </p>
          )}
        </div>

        <div className="form-field">
          <label htmlFor={fieldId('serialNumber')}>
            Serial number <span aria-hidden="true">*</span>
          </label>
          <input
            id={fieldId('serialNumber')}
            name="serialNumber"
            type="text"
            value={values.serialNumber}
            onChange={(event) =>
              updateField('serialNumber', event.target.value)
            }
            aria-invalid={Boolean(errors.serialNumber)}
            aria-describedby={describedBy('serialNumber')}
            autoComplete="off"
            required
          />
          {errors.serialNumber && (
            <p
              className="field-error"
              id={errorId('serialNumber')}
              role="alert"
            >
              {errors.serialNumber}
            </p>
          )}
        </div>

        <div className="form-field">
          <label htmlFor={fieldId('location')}>
            Location <span aria-hidden="true">*</span>
          </label>
          <input
            id={fieldId('location')}
            name="location"
            type="text"
            value={values.location}
            onChange={(event) => updateField('location', event.target.value)}
            aria-invalid={Boolean(errors.location)}
            aria-describedby={describedBy('location')}
            placeholder="e.g. London office"
            required
          />
          {errors.location && (
            <p className="field-error" id={errorId('location')} role="alert">
              {errors.location}
            </p>
          )}
        </div>

        <div className="form-field">
          <label htmlFor={fieldId('status')}>Status</label>
          <select
            id={fieldId('status')}
            name="status"
            value={values.status}
            onChange={(event) =>
              updateField('status', event.target.value as EquipmentStatus)
            }
          >
            <option value="Available">Available</option>
            <option value="In Use">In Use</option>
            <option value="Maintenance">Maintenance</option>
          </select>
        </div>

        <div className="form-field">
          <label htmlFor={fieldId('assignedTo')}>Assigned to</label>
          <input
            id={fieldId('assignedTo')}
            name="assignedTo"
            type="text"
            value={values.assignedTo}
            onChange={(event) => updateField('assignedTo', event.target.value)}
            placeholder="Optional"
            autoComplete="name"
          />
        </div>

        <div className="form-field">
          <label htmlFor={fieldId('purchaseDate')}>
            Purchase date <span aria-hidden="true">*</span>
          </label>
          <input
            id={fieldId('purchaseDate')}
            name="purchaseDate"
            type="date"
            value={values.purchaseDate}
            onChange={(event) =>
              updateField('purchaseDate', event.target.value)
            }
            aria-invalid={Boolean(errors.purchaseDate)}
            aria-describedby={describedBy('purchaseDate')}
            required
          />
          {errors.purchaseDate && (
            <p
              className="field-error"
              id={errorId('purchaseDate')}
              role="alert"
            >
              {errors.purchaseDate}
            </p>
          )}
        </div>

        <div className="form-field form-field-full">
          <label htmlFor={fieldId('notes')}>Notes</label>
          <textarea
            id={fieldId('notes')}
            name="notes"
            value={values.notes}
            onChange={(event) => updateField('notes', event.target.value)}
            rows={4}
            placeholder="Add any useful equipment details"
          />
        </div>
      </div>

      <p className="form-required-note">
        <span aria-hidden="true">*</span> Required fields
      </p>

      <div className="form-actions">
        <button type="button" className="button button-secondary" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="button button-primary">
          {submitLabel}
        </button>
      </div>
    </form>
  );
}
