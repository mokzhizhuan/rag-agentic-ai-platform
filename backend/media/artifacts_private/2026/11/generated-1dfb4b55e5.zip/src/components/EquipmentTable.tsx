import type { EquipmentTableProps, EquipmentStatus } from '../types';

const statusClassNames: Record<EquipmentStatus, string> = {
  Available: 'status-badge status-available',
  'In Use': 'status-badge status-in-use',
  Maintenance: 'status-badge status-maintenance',
};

function formatPurchaseDate(value: string): string {
  if (!value) {
    return '—';
  }

  const date = new Date(`${value}T00:00:00`);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat('en', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(date);
}

export default function EquipmentTable({
  equipment,
  onEdit,
  onDelete,
}: EquipmentTableProps) {
  if (equipment.length === 0) {
    return (
      <section className="table-card empty-state" aria-live="polite">
        <div className="empty-state-icon" aria-hidden="true">
          ▣
        </div>
        <h2>No equipment found</h2>
        <p>
          Try adjusting your search or filter, or add a new piece of equipment
          to your inventory.
        </p>
      </section>
    );
  }

  return (
    <section className="table-card" aria-labelledby="equipment-table-heading">
      <div className="table-card-header">
        <div>
          <h2 id="equipment-table-heading">Equipment inventory</h2>
          <p>
            {equipment.length} {equipment.length === 1 ? 'item' : 'items'} shown
          </p>
        </div>
      </div>

      <div className="table-wrapper">
        <table className="equipment-table">
          <caption className="sr-only">
            Equipment inventory with status and management actions
          </caption>
          <thead>
            <tr>
              <th scope="col">Equipment</th>
              <th scope="col">Category</th>
              <th scope="col">Serial number</th>
              <th scope="col">Location</th>
              <th scope="col">Status</th>
              <th scope="col">Assigned to</th>
              <th scope="col">Purchase date</th>
              <th scope="col">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {equipment.map((item) => (
              <tr key={item.id}>
                <td data-label="Equipment">
                  <div className="equipment-name-cell">
                    <strong>{item.name}</strong>
                    {item.notes && (
                      <span className="equipment-notes">{item.notes}</span>
                    )}
                  </div>
                </td>
                <td data-label="Category">{item.category}</td>
                <td data-label="Serial number">
                  <span className="serial-number">{item.serialNumber}</span>
                </td>
                <td data-label="Location">{item.location}</td>
                <td data-label="Status">
                  <span className={statusClassNames[item.status]}>
                    <span className="status-dot" aria-hidden="true" />
                    {item.status}
                  </span>
                </td>
                <td data-label="Assigned to">{item.assignedTo || 'Unassigned'}</td>
                <td data-label="Purchase date">
                  {formatPurchaseDate(item.purchaseDate)}
                </td>
                <td data-label="Actions">
                  <div className="row-actions">
                    <button
                      type="button"
                      className="button button-text"
                      onClick={() => onEdit(item)}
                      aria-label={`Edit ${item.name}`}
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      className="button button-text button-danger-text"
                      onClick={() => onDelete(item)}
                      aria-label={`Delete ${item.name}`}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
