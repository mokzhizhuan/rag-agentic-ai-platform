import type { HeaderProps } from '../types';

export default function Header({ onAddEquipment }: HeaderProps) {
  return (
    <header className="dashboard-header">
      <div className="header-content">
        <div>
          <p className="eyebrow">Operations overview</p>
          <h1>Equipment inventory</h1>
          <p className="header-description">
            Track equipment availability, assignments, locations, and maintenance status in one place.
          </p>
        </div>

        <button className="button button-primary" type="button" onClick={onAddEquipment}>
          <span aria-hidden="true">+</span>
          <span>Add equipment</span>
        </button>
      </div>
    </header>
  );
}
