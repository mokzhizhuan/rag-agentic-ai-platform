import { useEffect, useMemo, useRef } from 'react';
import EquipmentForm from './EquipmentForm';
import {
  EquipmentFormValues,
  EquipmentModalProps,
} from '../types';

export default function EquipmentModal({
  isOpen,
  mode,
  equipment,
  onClose,
  onSubmit,
}: EquipmentModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  const initialValues = useMemo<EquipmentFormValues | undefined>(() => {
    if (!equipment) {
      return undefined;
    }

    const { id: _id, ...values } = equipment;
    return values;
  }, [equipment]);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    document.body.classList.add('modal-open');
    closeButtonRef.current?.focus();

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.classList.remove('modal-open');
    };
  }, [isOpen, onClose]);

  if (!isOpen) {
    return null;
  }

  const title = mode === 'add' ? 'Add equipment' : 'Edit equipment';

  return (
    <div
      className="modal-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
    >
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="equipment-modal-title"
      >
        <div className="modal-header">
          <div>
            <p className="eyebrow">{mode === 'add' ? 'New record' : 'Update record'}</p>
            <h2 id="equipment-modal-title">{title}</h2>
          </div>
          <button
            ref={closeButtonRef}
            className="icon-button"
            type="button"
            onClick={onClose}
            aria-label="Close equipment form"
          >
            <span aria-hidden="true">×</span>
          </button>
        </div>

        <EquipmentForm
          initialValues={initialValues}
          onSubmit={onSubmit}
          onCancel={onClose}
          submitLabel={mode === 'add' ? 'Add equipment' : 'Save changes'}
        />
      </div>
    </div>
  );
}
