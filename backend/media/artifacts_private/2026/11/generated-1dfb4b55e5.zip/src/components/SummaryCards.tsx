import type { Equipment, SummaryCardsProps } from '../types';

interface SummaryMetric {
  label: string;
  value: number;
  description: string;
  className: string;
}

function getMetrics(equipment: Equipment[]): SummaryMetric[] {
  return [
    {
      label: 'Total equipment',
      value: equipment.length,
      description: 'All tracked assets',
      className: 'summary-card--total',
    },
    {
      label: 'Available',
      value: equipment.filter((item) => item.status === 'Available').length,
      description: 'Ready to assign',
      className: 'summary-card--available',
    },
    {
      label: 'In use',
      value: equipment.filter((item) => item.status === 'In Use').length,
      description: 'Currently assigned',
      className: 'summary-card--in-use',
    },
    {
      label: 'Maintenance',
      value: equipment.filter((item) => item.status === 'Maintenance').length,
      description: 'Needs attention',
      className: 'summary-card--maintenance',
    },
  ];
}

export default function SummaryCards({ equipment }: SummaryCardsProps) {
  const metrics = getMetrics(equipment);

  return (
    <section className="summary-section" aria-labelledby="inventory-summary-heading">
      <div className="section-heading">
        <h2 id="inventory-summary-heading">Inventory overview</h2>
      </div>

      <div className="summary-cards">
        {metrics.map((metric) => (
          <article className={`summary-card ${metric.className}`} key={metric.label}>
            <div className="summary-card__content">
              <p className="summary-card__label">{metric.label}</p>
              <p className="summary-card__value" aria-label={`${metric.value} ${metric.label}`}>
                {metric.value}
              </p>
              <p className="summary-card__description">{metric.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
