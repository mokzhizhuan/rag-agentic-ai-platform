import type {
  EquipmentSortField,
  EquipmentSortOption,
  EquipmentStatus,
  EquipmentToolbarProps,
  SortDirection,
} from '../types';

const statusOptions: Array<EquipmentStatus | 'All'> = [
  'All',
  'Available',
  'In Use',
  'Maintenance',
];

const sortOptions: Array<{
  value: string;
  label: string;
  field: EquipmentSortField;
  direction: SortDirection;
}> = [
  { value: 'name-asc', label: 'Name: A to Z', field: 'name', direction: 'asc' },
  { value: 'name-desc', label: 'Name: Z to A', field: 'name', direction: 'desc' },
  {
    value: 'category-asc',
    label: 'Category: A to Z',
    field: 'category',
    direction: 'asc',
  },
  {
    value: 'category-desc',
    label: 'Category: Z to A',
    field: 'category',
    direction: 'desc',
  },
  {
    value: 'location-asc',
    label: 'Location: A to Z',
    field: 'location',
    direction: 'asc',
  },
  {
    value: 'location-desc',
    label: 'Location: Z to A',
    field: 'location',
    direction: 'desc',
  },
  {
    value: 'status-asc',
    label: 'Status: A to Z',
    field: 'status',
    direction: 'asc',
  },
  {
    value: 'status-desc',
    label: 'Status: Z to A',
    field: 'status',
    direction: 'desc',
  },
  {
    value: 'purchaseDate-desc',
    label: 'Purchase date: Newest',
    field: 'purchaseDate',
    direction: 'desc',
  },
  {
    value: 'purchaseDate-asc',
    label: 'Purchase date: Oldest',
    field: 'purchaseDate',
    direction: 'asc',
  },
];

function getSortValue(sort: EquipmentSortOption): string {
  return `${sort.field}-${sort.direction}`;
}

export default function EquipmentToolbar({
  searchTerm,
  statusFilter,
  sort,
  onSearchChange,
  onStatusFilterChange,
  onSortChange,
  onAddEquipment,
}: EquipmentToolbarProps) {
  const selectedSortValue = getSortValue(sort);

  const handleSortChange = (value: string) => {
    const selectedOption = sortOptions.find((option) => option.value === value);

    if (selectedOption) {
      onSortChange({
        field: selectedOption.field,
        direction: selectedOption.direction,
      });
    }
  };

  return (
    <section className="toolbar" aria-label="Equipment table controls">
      <div className="toolbar-filters">
        <div className="field-group search-field">
          <label htmlFor="equipment-search">Search equipment</label>
          <div className="search-input-wrapper">
            <span className="search-icon" aria-hidden="true">
              ⌕
            </span>
            <input
              id="equipment-search"
              type="search"
              value={searchTerm}
              onChange={(event) => onSearchChange(event.target.value)}
              placeholder="Search by name, serial number, or location"
              autoComplete="off"
            />
          </div>
        </div>

        <div className="field-group">
          <label htmlFor="status-filter">Status</label>
          <select
            id="status-filter"
            value={statusFilter}
            onChange={(event) =>
              onStatusFilterChange(
                event.target.value as EquipmentStatus | 'All',
              )
            }
          >
            {statusOptions.map((status) => (
              <option key={status} value={status}>
                {status === 'All' ? 'All statuses' : status}
              </option>
            ))}
          </select>
        </div>

        <div className="field-group">
          <label htmlFor="equipment-sort">Sort by</label>
          <select
            id="equipment-sort"
            value={selectedSortValue}
            onChange={(event) => handleSortChange(event.target.value)}
          >
            {sortOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <button
        className="button button-primary"
        type="button"
        onClick={onAddEquipment}
      >
        <span aria-hidden="true">+</span>
        Add equipment
      </button>
    </section>
  );
}
