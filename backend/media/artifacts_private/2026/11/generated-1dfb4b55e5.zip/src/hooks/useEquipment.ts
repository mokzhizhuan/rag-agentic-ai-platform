import { useCallback, useEffect, useState } from 'react';
import { mockEquipment } from '../data/mockEquipment';
import type {
  Equipment,
  EquipmentFormValues,
  EquipmentStatus,
  UseEquipmentResult,
} from '../types';

const STORAGE_KEY = 'equipment-inventory-data';

const statuses: EquipmentStatus[] = ['Available', 'In Use', 'Maintenance'];

const isEquipment = (value: unknown): value is Equipment => {
  if (!value || typeof value !== 'object') {
    return false;
  }

  const record = value as Record<string, unknown>;

  return (
    typeof record.id === 'string' &&
    typeof record.name === 'string' &&
    typeof record.category === 'string' &&
    typeof record.serialNumber === 'string' &&
    typeof record.location === 'string' &&
    typeof record.status === 'string' &&
    statuses.includes(record.status as EquipmentStatus) &&
    typeof record.assignedTo === 'string' &&
    typeof record.purchaseDate === 'string' &&
    typeof record.notes === 'string'
  );
};

const getInitialEquipment = (): Equipment[] => {
  if (typeof window === 'undefined') {
    return mockEquipment;
  }

  try {
    const storedData = window.localStorage.getItem(STORAGE_KEY);

    if (!storedData) {
      return mockEquipment;
    }

    const parsedData: unknown = JSON.parse(storedData);

    return Array.isArray(parsedData) && parsedData.every(isEquipment)
      ? parsedData
      : mockEquipment;
  } catch {
    return mockEquipment;
  }
};

const createEquipmentId = (): string => {
  const randomPart = Math.random().toString(36).slice(2, 10);
  return `eq-${Date.now()}-${randomPart}`;
};

export const useEquipment = (): UseEquipmentResult => {
  const [equipment, setEquipment] = useState<Equipment[]>(getInitialEquipment);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(equipment));
    } catch {
      // Storage may be unavailable or full; the in-memory state remains usable.
    }
  }, [equipment]);

  const addEquipment = useCallback((values: EquipmentFormValues) => {
    setEquipment((currentEquipment) => [
      ...currentEquipment,
      {
        ...values,
        id: createEquipmentId(),
      },
    ]);
  }, []);

  const updateEquipment = useCallback(
    (id: string, values: EquipmentFormValues) => {
      setEquipment((currentEquipment) =>
        currentEquipment.map((item) =>
          item.id === id
            ? {
                ...values,
                id,
              }
            : item,
        ),
      );
    },
    [],
  );

  const deleteEquipment = useCallback((id: string) => {
    setEquipment((currentEquipment) =>
      currentEquipment.filter((item) => item.id !== id),
    );
  }, []);

  return {
    equipment,
    addEquipment,
    updateEquipment,
    deleteEquipment,
  };
};
