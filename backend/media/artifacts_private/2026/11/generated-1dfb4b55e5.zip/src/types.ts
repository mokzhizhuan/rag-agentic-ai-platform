export type EquipmentStatus = 'Available' | 'In Use' | 'Maintenance';

export type Status = EquipmentStatus;

export interface Equipment {
  id: string;
  name: string;
  category: string;
  serialNumber: string;
  location: string;
  status: EquipmentStatus;
  assignedTo: string;
  purchaseDate: string;
  notes: string;
}

export type EquipmentFormValues = Omit<Equipment, 'id'>;

export type EquipmentSortField =
  | 'name'
  | 'category'
  | 'location'
  | 'status'
  | 'purchaseDate';

export type SortDirection = 'asc' | 'desc';

export interface EquipmentSortOption {
  field: EquipmentSortField;
  direction: SortDirection;
}

export interface HeaderProps {
  onAddEquipment: () => void;
}

export interface SummaryCardsProps {
  equipment: Equipment[];
}

export interface EquipmentToolbarProps {
  searchTerm: string;
  statusFilter: EquipmentStatus | 'All';
  sort: EquipmentSortOption;
  onSearchChange: (value: string) => void;
  onStatusFilterChange: (value: EquipmentStatus | 'All') => void;
  onSortChange: (sort: EquipmentSortOption) => void;
  onAddEquipment: () => void;
}

export interface EquipmentTableProps {
  equipment: Equipment[];
  onEdit: (equipment: Equipment) => void;
  onDelete: (equipment: Equipment) => void;
}

export interface EquipmentFormProps {
  initialValues?: EquipmentFormValues;
  onSubmit: (values: EquipmentFormValues) => void;
  onCancel: () => void;
  submitLabel?: string;
}

export interface EquipmentModalProps {
  isOpen: boolean;
  mode: 'add' | 'edit';
  equipment?: Equipment | null;
  onClose: () => void;
  onSubmit: (values: EquipmentFormValues) => void;
}

export interface DeleteConfirmationProps {
  equipment: Equipment | null;
  isOpen: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export interface UseEquipmentResult {
  equipment: Equipment[];
  addEquipment: (values: EquipmentFormValues) => void;
  updateEquipment: (id: string, values: EquipmentFormValues) => void;
  deleteEquipment: (id: string) => void;
}
