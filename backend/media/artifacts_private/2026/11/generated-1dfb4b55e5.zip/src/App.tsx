import { useMemo, useState } from 'react';
import Header from './components/Header';
import SummaryCards from './components/SummaryCards';
import EquipmentToolbar from './components/EquipmentToolbar';
import EquipmentTable from './components/EquipmentTable';
import EquipmentModal from './components/EquipmentModal';
import DeleteConfirmation from './components/DeleteConfirmation';
import { useEquipment } from './hooks/useEquipment';
import type {
  Equipment,
  EquipmentFormValues,
  EquipmentSortOption,
  EquipmentStatus,
} from './types';

const defaultSort: EquipmentSortOption = {
  field: 'name',
  direction: 'asc',
};

function App() {
  const {
    equipment,
    addEquipment,
    updateEquipment,
    deleteEquipment,
  } = useEquipment();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<EquipmentStatus | 'All'>(
    'All',
  );
  const [sort, setSort] = useState<EquipmentSortOption>(defaultSort);
  const [isEquipmentModalOpen, setIsEquipmentModalOpen] = useState(false);
  const [equipmentModalMode, setEquipmentModalMode] = useState<'add' | 'edit'>(
    'add',
  );
  const [selectedEquipment, setSelectedEquipment] =
    useState<Equipment | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const filteredEquipment = useMemo(() => {
    const normalizedSearch = searchTerm.trim().toLowerCase();

    const matchingEquipment = equipment.filter((item) => {
      const matchesStatus =
        statusFilter === 'All' || item.status === statusFilter;

      if (!matchesStatus) {
        return false;
      }

      if (!normalizedSearch) {
        return true;
      }

      return [
        item.name,
        item.category,
        item.serialNumber,
        item.location,
        item.status,
        item.assignedTo,
        item.purchaseDate,
        item.notes,
      ].some((value) => value.toLowerCase().includes(normalizedSearch));
    });

    return [...matchingEquipment].sort((first, second) => {
      const firstValue = first[sort.field];
      const secondValue = second[sort.field];

      let comparison: number;

      if (sort.field === 'purchaseDate') {
        comparison = firstValue.localeCompare(secondValue);
      } else {
        comparison = firstValue.localeCompare(secondValue, undefined, {
          sensitivity: 'base',
          numeric: true,
        });
      }

      return sort.direction === 'asc' ? comparison : -comparison;
    });
  }, [equipment, searchTerm, sort, statusFilter]);

  const handleOpenAddModal = () => {
    setSelectedEquipment(null);
    setEquipmentModalMode('add');
    setIsEquipmentModalOpen(true);
  };

  const handleOpenEditModal = (item: Equipment) => {
    setSelectedEquipment(item);
    setEquipmentModalMode('edit');
    setIsEquipmentModalOpen(true);
  };

  const handleCloseEquipmentModal = () => {
    setIsEquipmentModalOpen(false);
    setSelectedEquipment(null);
  };

  const handleEquipmentSubmit = (values: EquipmentFormValues) => {
    if (equipmentModalMode === 'edit' && selectedEquipment) {
      updateEquipment(selectedEquipment.id, values);
    } else {
      addEquipment(values);
    }

    handleCloseEquipmentModal();
  };

  const handleOpenDeleteDialog = (item: Equipment) => {
    setSelectedEquipment(item);
    setIsDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setIsDeleteDialogOpen(false);
    setSelectedEquipment(null);
  };

  const handleConfirmDelete = () => {
    if (selectedEquipment) {
      deleteEquipment(selectedEquipment.id);
    }

    handleCloseDeleteDialog();
  };

  return (
    <div className="app-shell">
      <Header onAddEquipment={handleOpenAddModal} />

      <main className="dashboard-main">
        <SummaryCards equipment={equipment} />

        <section
          className="inventory-section"
          aria-labelledby="inventory-management-heading"
        >
          <div className="section-heading">
            <div>
              <p className="eyebrow">Asset management</p>
              <h2 id="inventory-management-heading">Manage inventory</h2>
            </div>
          </div>

          <EquipmentToolbar
            searchTerm={searchTerm}
            statusFilter={statusFilter}
            sort={sort}
            onSearchChange={setSearchTerm}
            onStatusFilterChange={setStatusFilter}
            onSortChange={setSort}
            onAddEquipment={handleOpenAddModal}
          />

          <EquipmentTable
            equipment={filteredEquipment}
            onEdit={handleOpenEditModal}
            onDelete={handleOpenDeleteDialog}
          />
        </section>
      </main>

      <EquipmentModal
        isOpen={isEquipmentModalOpen}
        mode={equipmentModalMode}
        equipment={selectedEquipment}
        onClose={handleCloseEquipmentModal}
        onSubmit={handleEquipmentSubmit}
      />

      <DeleteConfirmation
        equipment={selectedEquipment}
        isOpen={isDeleteDialogOpen}
        onCancel={handleCloseDeleteDialog}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}

export default App;
