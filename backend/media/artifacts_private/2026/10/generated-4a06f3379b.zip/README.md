# Responsive CCTV Monitoring Dashboard

A framework-free, responsive CCTV monitoring dashboard built with standard HTML, CSS, and JavaScript. The interface displays four sample cameras, supports camera search and status filtering, and provides monitoring actions for online cameras.

## Project Files

- `index.html` — Semantic dashboard structure, controls, camera grid mount point, empty state, connection status, and asset references.
- `styles.css` — Responsive layout and visual styling for the dashboard, filters, cards, status badges, buttons, and mobile breakpoints.
- `app.js` — Camera data, rendering logic, search and status filtering, result counts, empty-state handling, and monitoring interactions.
- `README.md` — Project documentation and local setup instructions.

## File Relationships

`index.html` references the stylesheet and JavaScript using the following paths:

- `styles.css`
- `app.js`

The JavaScript is loaded with `defer`, so the document structure is available before application initialization.

## Running Locally

No build process or package installation is required.

### Option 1: Open Directly

Open `index.html` in a modern web browser.

### Option 2: Use a Local HTTP Server

From the project directory, run a local server with an available tool.

Using Python:

    python3 -m http.server 8000

Then open:

    http://localhost:8000

Using Node.js and a globally installed static server:

    npx serve .

The dashboard is a static front-end and does not require environment variables, API keys, a database, or a backend service.

## Camera Data Schema

The static `cameras` array in `app.js` contains objects with the following fields:

| Field | Type | Description |
|---|---|---|
| `id` | String | Unique camera identifier, such as `cam-001`. |
| `name` | String | Display name of the camera. |
| `location` | String | Physical camera location. |
| `status` | String | Availability status. Must be exactly `online` or `offline`. |
| `streamUrl` | String | Placeholder or future stream endpoint for the camera. |
| `lastSeen` | String | Human-readable most recent connection time. |
| `thumbnail` | String | Camera preview image URL. |

The included stream URLs are placeholders and do not provide real video streams. The thumbnail URLs are sample image resources and may be replaced with local assets or production camera imagery.

## Required DOM IDs

`app.js` expects the following elements in `index.html`:

| ID | Purpose |
|---|---|
| `cameraSearch` | Search input for camera names and locations. |
| `statusFilter` | Select control for all, online, or offline cameras. |
| `cameraGrid` | Container where filtered camera cards are rendered. |
| `resultCount` | Displays the number of matching cameras. |
| `emptyState` | Shown when no cameras match the active filters. |
| `connectionStatus` | Displays monitoring connection feedback. |

Changing or removing these IDs requires corresponding updates in `app.js`.

## Filtering Behavior

### Search

The search field filters cameras by:

- Camera name
- Camera location

Search is case-insensitive and matches partial text. For example, searching for `north` matches a camera whose location contains `North Building`.

### Status

The status selector supports exactly three values:

- `all`
- `online`
- `offline`

Search and status filters are combined, so both conditions must match for a camera to be displayed.

### Empty Results

When no cameras match the current search and status filters:

- The camera grid is cleared.
- The result count is updated to zero.
- The empty-state message is displayed.

## Camera Cards

Each rendered camera card includes:

- A `data-camera-id` attribute.
- Camera thumbnail and accessible image text.
- Online or offline status badge.
- Camera name.
- Location.
- Last-seen information.
- Monitoring action.

Online cameras have an enabled monitoring button. Offline cameras display a disabled action and cannot be monitored.

Selecting an online camera updates the connection status and changes its action label to indicate that monitoring is active. The current implementation represents a front-end interaction only; it does not connect to a real stream server.

## Responsive Design

The dashboard uses CSS Grid, Flexbox, fluid sizing, and mobile breakpoints without external frameworks.

The layout includes:

- Two-column camera grid on larger screens.
- Single-column camera layout on narrow screens.
- Flexible search and status filter controls.
- Responsive header and summary content.
- Touch-friendly buttons and form controls.
- Minimum page width support for small mobile viewports.

## Browser Support

The project is intended for current versions of:

- Chrome
- Edge
- Firefox
- Safari

The implementation uses standard browser APIs including:

- `querySelector`
- `addEventListener`
- Template literals
- `Array.prototype.filter`
- `Array.prototype.map`
- `CSS.escape`

## Extending the Dashboard

To add or replace cameras, edit the `cameras` array in `app.js` and provide all required schema fields. Keep status values limited to `online` and `offline` so filtering, badges, and monitoring controls continue to work correctly.

For production use, the static camera array can be replaced with data loaded from an authenticated backend API. Real stream playback would also require a compatible streaming service and appropriate access controls.
