const cameras = [
  {
    id: "cam-001",
    name: "Main Entrance",
    location: "North Building · Ground Floor",
    status: "online",
    streamUrl: "https://example.com/streams/cam-001",
    lastSeen: "Just now",
    thumbnail: "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "cam-002",
    name: "Parking Lot",
    location: "West Campus · Outdoor",
    status: "online",
    streamUrl: "https://example.com/streams/cam-002",
    lastSeen: "2 minutes ago",
    thumbnail: "https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "cam-003",
    name: "Reception Area",
    location: "South Building · Level 1",
    status: "offline",
    streamUrl: "https://example.com/streams/cam-003",
    lastSeen: "18 minutes ago",
    thumbnail: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "cam-004",
    name: "Warehouse Loading Bay",
    location: "Operations Center · Bay 3",
    status: "online",
    streamUrl: "https://example.com/streams/cam-004",
    lastSeen: "1 minute ago",
    thumbnail: "https://images.unsplash.com/photo-1586528116493-da8d3d8b5a20?auto=format&fit=crop&w=900&q=80"
  }
];

const cameraSearch = document.getElementById("cameraSearch");
const statusFilter = document.getElementById("statusFilter");
const cameraGrid = document.getElementById("cameraGrid");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
const connectionStatus = document.getElementById("connectionStatus");

function escapeAttribute(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function getFilteredCameras() {
  const query = cameraSearch.value.trim().toLowerCase();
  const selectedStatus = statusFilter.value;

  return cameras.filter((camera) => {
    const matchesQuery =
      !query ||
      camera.name.toLowerCase().includes(query) ||
      camera.location.toLowerCase().includes(query);

    const matchesStatus =
      selectedStatus === "all" || camera.status === selectedStatus;

    return matchesQuery && matchesStatus;
  });
}

function renderCameras() {
  const filteredCameras = getFilteredCameras();

  resultCount.textContent = `${filteredCameras.length} ${
    filteredCameras.length === 1 ? "camera" : "cameras"
  }`;

  emptyState.hidden = filteredCameras.length !== 0;

  cameraGrid.innerHTML = filteredCameras
    .map((camera) => {
      const isOnline = camera.status === "online";
      const statusLabel = isOnline ? "Online" : "Offline";

      return `
        <article class="camera-card ${camera.status}" data-camera-id="${escapeAttribute(camera.id)}">
          <div class="camera-thumbnail">
            <img src="${escapeAttribute(camera.thumbnail)}" alt="${escapeAttribute(camera.name)} camera view" loading="lazy">
            <span class="status-badge ${camera.status}">
              <span class="status-dot" aria-hidden="true"></span>
              ${statusLabel}
            </span>
          </div>
          <div class="camera-card-content">
            <div class="camera-card-heading">
              <div>
                <h3>${escapeAttribute(camera.name)}</h3>
                <p class="camera-location">${escapeAttribute(camera.location)}</p>
              </div>
            </div>
            <p class="last-seen">
              <span aria-hidden="true">◷</span>
              Last seen: ${escapeAttribute(camera.lastSeen)}
            </p>
            <button
              class="monitor-button"
              type="button"
              data-action="monitor"
              data-camera-id="${escapeAttribute(camera.id)}"
              ${isOnline ? "" : "disabled"}
              aria-label="${isOnline ? `Monitor ${escapeAttribute(camera.name)}` : `${escapeAttribute(camera.name)} is offline`}"
            >
              ${isOnline ? "Monitor camera" : "Unavailable"}
            </button>
          </div>
        </article>
      `;
    })
    .join("");
}

function monitorCamera(cameraId) {
  const camera = cameras.find((item) => item.id === cameraId);

  if (!camera || camera.status !== "online") {
    return;
  }

  connectionStatus.textContent = `Connecting to ${camera.name}`;

  const button = cameraGrid.querySelector(
    `[data-camera-id="${CSS.escape(cameraId)}"][data-action="monitor"]`
  );

  if (button) {
    button.textContent = "Monitoring";
    button.classList.add("is-active");
  }

  window.setTimeout(() => {
    connectionStatus.textContent = `${camera.name} monitoring active`;
  }, 500);
}

cameraSearch.addEventListener("input", renderCameras);
statusFilter.addEventListener("change", renderCameras);

cameraGrid.addEventListener("click", (event) => {
  const monitorButton = event.target.closest('[data-action="monitor"]');

  if (monitorButton && !monitorButton.disabled) {
    monitorCamera(monitorButton.dataset.cameraId);
  }
});

renderCameras();
