#!/usr/bin/env python3
"""Validate CCTV device records from a CSV file using YAML configuration."""

from __future__ import annotations

import argparse
import csv
import ipaddress
import math
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml


CANONICAL_FIELDS = [
    "device_id",
    "site_code",
    "camera_name",
    "ip_address",
    "model",
    "firmware_version",
    "status",
    "latitude",
    "longitude",
    "last_seen_at",
]

REPORT_FIELDS = ["device_id", "is_valid", "error_count", "errors"]


def load_settings(config_path: Path) -> dict[str, Any]:
    """Load and validate the YAML settings file."""
    try:
        with config_path.open("r", encoding="utf-8") as config_file:
            settings = yaml.safe_load(config_file) or {}
    except OSError as exc:
        raise ValueError(f"Unable to read configuration: {exc}") from exc
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML configuration: {exc}") from exc

    if not isinstance(settings, dict):
        raise ValueError("Configuration must contain a YAML mapping.")

    return settings


def resolve_path(path_value: str, base_dir: Path) -> Path:
    """Resolve a configured path relative to the current working directory."""
    path = Path(path_value).expanduser()
    return path if path.is_absolute() else base_dir / path


def parse_float(value: str, field_name: str) -> tuple[float | None, str | None]:
    """Parse a finite floating-point value."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None, f"{field_name} must be a number"

    if not math.isfinite(number):
        return None, f"{field_name} must be finite"

    return number, None


def validate_record(
    record: dict[str, Any],
    allowed_statuses: set[str],
    latitude_min: float,
    latitude_max: float,
    longitude_min: float,
    longitude_max: float,
) -> list[str]:
    """Return validation errors for one CCTV device record."""
    errors: list[str] = []

    required_fields = [
        "device_id",
        "site_code",
        "camera_name",
        "model",
        "firmware_version",
        "status",
        "last_seen_at",
    ]

    for field_name in required_fields:
        if not str(record.get(field_name, "") or "").strip():
            errors.append(f"{field_name} is required")

    status = str(record.get("status", "") or "").strip().lower()
    if status and status not in allowed_statuses:
        errors.append(
            "status must be one of: " + ", ".join(sorted(allowed_statuses))
        )

    ip_address = str(record.get("ip_address", "") or "").strip()
    if not ip_address:
        errors.append("ip_address is required")
    else:
        try:
            ipaddress.ip_address(ip_address)
        except ValueError:
            errors.append("ip_address must be a valid IPv4 or IPv6 address")

    latitude, latitude_error = parse_float(
        str(record.get("latitude", "") or "").strip(), "latitude"
    )
    if latitude_error:
        errors.append(latitude_error)
    elif latitude is not None and not latitude_min <= latitude <= latitude_max:
        errors.append(
            f"latitude must be between {latitude_min} and {latitude_max}"
        )

    longitude, longitude_error = parse_float(
        str(record.get("longitude", "") or "").strip(), "longitude"
    )
    if longitude_error:
        errors.append(longitude_error)
    elif longitude is not None and not longitude_min <= longitude <= longitude_max:
        errors.append(
            f"longitude must be between {longitude_min} and {longitude_max}"
        )

    last_seen_at = str(record.get("last_seen_at", "") or "").strip()
    if last_seen_at:
        normalized_timestamp = (
            last_seen_at[:-1] + "+00:00"
            if last_seen_at.endswith(("Z", "z"))
            else last_seen_at
        )
        try:
            datetime.fromisoformat(normalized_timestamp)
        except ValueError:
            errors.append("last_seen_at must be a valid ISO 8601 timestamp")

    return errors


def validate_csv(
    input_path: Path,
    output_path: Path,
    settings: dict[str, Any],
) -> int:
    """Validate CSV records and write a CSV validation report."""
    validation_settings = settings.get("validation", {})
    if not isinstance(validation_settings, dict):
        raise ValueError("The validation configuration must be a mapping.")

    allowed_statuses = {
        str(status).strip().lower()
        for status in validation_settings.get(
            "allowed_statuses", ["active", "inactive", "maintenance"]
        )
    }

    latitude_min = float(validation_settings.get("latitude_min", -90.0))
    latitude_max = float(validation_settings.get("latitude_max", 90.0))
    longitude_min = float(validation_settings.get("longitude_min", -180.0))
    longitude_max = float(validation_settings.get("longitude_max", 180.0))

    reports: list[dict[str, str]] = []

    try:
        with input_path.open("r", encoding="utf-8-sig", newline="") as input_file:
            reader = csv.DictReader(input_file)

            if reader.fieldnames is None:
                raise ValueError("Input CSV is missing a header row.")

            missing_fields = [
                field for field in CANONICAL_FIELDS if field not in reader.fieldnames
            ]
            unexpected_fields = [
                field for field in reader.fieldnames if field not in CANONICAL_FIELDS
            ]

            if missing_fields or unexpected_fields:
                header_errors = []
                if missing_fields:
                    header_errors.append(
                        "missing fields: " + ", ".join(missing_fields)
                    )
                if unexpected_fields:
                    header_errors.append(
                        "unexpected fields: " + ", ".join(unexpected_fields)
                    )
                raise ValueError("Invalid CSV header; " + "; ".join(header_errors))

            for row_number, record in enumerate(reader, start=2):
                device_id = str(record.get("device_id", "") or "").strip()
                errors = validate_record(
                    record,
                    allowed_statuses,
                    latitude_min,
                    latitude_max,
                    longitude_min,
                    longitude_max,
                )

                if None in record.values():
                    errors.append(f"row {row_number} contains too many columns")

                reports.append(
                    {
                        "device_id": device_id,
                        "is_valid": "true" if not errors else "false",
                        "error_count": str(len(errors)),
                        "errors": "; ".join(errors),
                    }
                )
    except OSError as exc:
        raise ValueError(f"Unable to read input CSV: {exc}") from exc
    except csv.Error as exc:
        raise ValueError(f"Invalid CSV data: {exc}") from exc

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8", newline="") as output_file:
            writer = csv.DictWriter(output_file, fieldnames=REPORT_FIELDS)
            writer.writeheader()
            writer.writerows(reports)
    except OSError as exc:
        raise ValueError(f"Unable to write validation report: {exc}") from exc

    return sum(report["is_valid"] == "false" for report in reports)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate CCTV device records from a CSV file."
    )
    parser.add_argument(
        "--config",
        default="config/settings.yaml",
        help="Path to the YAML settings file.",
    )
    parser.add_argument("--input", help="Override the configured input CSV path.")
    parser.add_argument("--output", help="Override the configured report CSV path.")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit with status 1 when any invalid records are found.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    try:
        config_path = Path(args.config).expanduser()
        settings = load_settings(config_path)

        data_settings = settings.get("data", {})
        validation_settings = settings.get("validation", {})

        if not isinstance(data_settings, dict):
            raise ValueError("The data configuration must be a mapping.")
        if not isinstance(validation_settings, dict):
            raise ValueError("The validation configuration must be a mapping.")

        input_value = args.input or data_settings.get(
            "input_csv", "sample_data/cctv_devices.csv"
        )
        output_value = args.output or validation_settings.get(
            "report_csv", "reports/cctv_validation_report.csv"
        )

        input_path = resolve_path(str(input_value), Path.cwd())
        output_path = resolve_path(str(output_value), Path.cwd())

        invalid_count = validate_csv(input_path, output_path, settings)
        strict = args.strict or bool(validation_settings.get("strict", False))

        print(f"Validation report written to {output_path}")
        print(f"Invalid records: {invalid_count}")

        return 1 if strict and invalid_count else 0
    except (ValueError, TypeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
