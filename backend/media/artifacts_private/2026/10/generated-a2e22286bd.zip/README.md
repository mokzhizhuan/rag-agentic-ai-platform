# CCTV Device Data Processor

A small local data-processing project for validating CCTV device records from CSV files and preparing a PostgreSQL schema for future loading.

The validator performs local checks only. It does not connect to PostgreSQL or require database credentials.

## Project layout

- `config/settings.yaml` — non-secret application and validation settings.
- `sample_data/cctv_devices.csv` — representative CCTV device records.
- `src/validate_cctv_devices.py` — CSV validation script.
- `sql/schema.sql` — PostgreSQL schema for the `cctv_devices` table.
- `requirements.txt` — Python runtime dependency.
- `.env.example` — environment variable names reserved for optional future database integration.
- `reports/cctv_validation_report.csv` — generated validation report; the directory and file are created when the validator runs.

## Requirements

- Python 3.10 or later
- PostgreSQL, only if the schema is being installed
- Access to a shell for running the commands below

The validator uses PyYAML and does not require a PostgreSQL driver.

## Installation

Create and activate a virtual environment if desired:

    python -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt

On Windows PowerShell, activate the environment with:

    .venv\Scripts\Activate.ps1

Then install the dependency:

    python -m pip install -r requirements.txt

## Configuration

The default configuration is in `config/settings.yaml`:

- Database host: `localhost`
- Database port: `5432`
- Database name: `cctv_monitoring`
- Database user: `cctv_app`
- Input CSV: `sample_data/cctv_devices.csv`
- Validation report: `reports/cctv_validation_report.csv`
- Strict mode: `false`

These database values are connection metadata only. No password or credential is stored in the project.

Relative paths in the configuration are resolved from the current working directory. Command-line input and output paths can override the configured paths.

## Validate the sample data

Run the validator from the project root:

    python src/validate_cctv_devices.py --config config/settings.yaml

The command writes:

    reports/cctv_validation_report.csv

The report contains these fields:

- `device_id`
- `is_valid`
- `error_count`
- `errors`

The default command exits successfully after writing the report, even when invalid records are found, because strict mode is disabled in the configuration.

To fail with exit status `1` when one or more records are invalid, use:

    python src/validate_cctv_devices.py --config config/settings.yaml --strict

The command-line `--strict` option takes precedence as an explicit failure request. An input or output error also causes a nonzero exit status.

## Command-line options

The validator supports:

    python src/validate_cctv_devices.py [options]

Options:

- `--config` — path to the YAML settings file. Defaults to `config/settings.yaml`.
- `--input` — override `data.input_csv`.
- `--output` — override `validation.report_csv`.
- `--strict` — exit with status `1` when invalid records are found.

Example with overridden paths:

    python src/validate_cctv_devices.py --config config/settings.yaml --input sample_data/cctv_devices.csv --output reports/cctv_validation_report.csv --strict

## Canonical record fields

The CSV header and PostgreSQL columns use the following exact snake_case field names:

1. `device_id`
2. `site_code`
3. `camera_name`
4. `ip_address`
5. `model`
6. `firmware_version`
7. `status`
8. `latitude`
9. `longitude`
10. `last_seen_at`

The input CSV must contain exactly these fields. Missing or unexpected header fields are reported as an input error.

## Validation rules

Each record must have a non-empty value for:

- `device_id`
- `site_code`
- `camera_name`
- `model`
- `firmware_version`
- `status`
- `last_seen_at`

Additional rules are:

- `status` must be `active`, `inactive`, or `maintenance`.
- `ip_address` must be a valid IPv4 or IPv6 address.
- `latitude` must be a finite number between `-90.0` and `90.0`.
- `longitude` must be a finite number between `-180.0` and `180.0`.
- `last_seen_at` must be a valid ISO 8601 timestamp.
- Extra CSV values beyond the declared fields are invalid.

The validator preserves the input record order in the report. Multiple errors for a record are separated by semicolons in the `errors` field.

## PostgreSQL schema

The PostgreSQL definition is in `sql/schema.sql`. It creates the `cctv_devices` table with:

- `device_id` as the primary key
- `TEXT` columns for identifying and descriptive fields
- PostgreSQL `INET` storage for IPv4 and IPv6 addresses
- `NUMERIC(9, 6)` coordinates
- `TIMESTAMPTZ` for `last_seen_at`
- A status constraint allowing `active`, `inactive`, or `maintenance`
- Coordinate range and pair-consistency checks
- Indexes for `site_code`, `status`, and `last_seen_at`

Apply the schema using a PostgreSQL client connected to the intended database:

    psql --host localhost --port 5432 --dbname cctv_monitoring --username cctv_app --file sql/schema.sql

The command may prompt for authentication depending on the local PostgreSQL configuration. Credentials are not included in this project and must be supplied externally.

The schema is suitable for future database loading, but the current Python validator intentionally performs CSV validation only.

## Sample data

`sample_data/cctv_devices.csv` contains three representative records using:

- IPv4 and IPv6 addresses
- `active`, `inactive`, and `maintenance` statuses
- Decimal latitude and longitude values
- UTC ISO 8601 timestamps

The sample values are illustrative and should be replaced or extended with authorized operational data as appropriate.

## Credentials and environment variables

`.env.example` contains names for optional future database integration only. It does not contain passwords or real credentials. If database loading is added later, credentials must be provided through an approved external secret-management or environment configuration process.

Do not commit passwords, private keys, access tokens, or production connection strings to this project.
