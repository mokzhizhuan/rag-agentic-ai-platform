CREATE TABLE IF NOT EXISTS cctv_devices (
    device_id         TEXT PRIMARY KEY,
    site_code         TEXT NOT NULL,
    camera_name       TEXT NOT NULL,
    ip_address        INET NOT NULL,
    model             TEXT NOT NULL,
    firmware_version  TEXT NOT NULL,
    status             TEXT NOT NULL,
    latitude          NUMERIC(9, 6),
    longitude         NUMERIC(9, 6),
    last_seen_at      TIMESTAMPTZ NOT NULL,

    CONSTRAINT cctv_devices_device_id_not_empty
        CHECK (btrim(device_id) <> ''),
    CONSTRAINT cctv_devices_site_code_not_empty
        CHECK (btrim(site_code) <> ''),
    CONSTRAINT cctv_devices_camera_name_not_empty
        CHECK (btrim(camera_name) <> ''),
    CONSTRAINT cctv_devices_model_not_empty
        CHECK (btrim(model) <> ''),
    CONSTRAINT cctv_devices_firmware_version_not_empty
        CHECK (btrim(firmware_version) <> ''),
    CONSTRAINT cctv_devices_status_check
        CHECK (status IN ('active', 'inactive', 'maintenance')),
    CONSTRAINT cctv_devices_latitude_check
        CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
    CONSTRAINT cctv_devices_longitude_check
        CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180),
    CONSTRAINT cctv_devices_coordinates_check
        CHECK (
            (latitude IS NULL AND longitude IS NULL)
            OR (latitude IS NOT NULL AND longitude IS NOT NULL)
        )
);

CREATE INDEX IF NOT EXISTS idx_cctv_devices_site_code
    ON cctv_devices (site_code);

CREATE INDEX IF NOT EXISTS idx_cctv_devices_status
    ON cctv_devices (status);

CREATE INDEX IF NOT EXISTS idx_cctv_devices_last_seen_at
    ON cctv_devices (last_seen_at);

COMMENT ON TABLE cctv_devices IS
    'CCTV device records used for monitoring and validation.';

COMMENT ON COLUMN cctv_devices.device_id IS
    'Unique identifier for the CCTV device.';

COMMENT ON COLUMN cctv_devices.site_code IS
    'Code identifying the installation site.';

COMMENT ON COLUMN cctv_devices.camera_name IS
    'Human-readable camera name.';

COMMENT ON COLUMN cctv_devices.ip_address IS
    'IPv4 or IPv6 address of the CCTV device.';

COMMENT ON COLUMN cctv_devices.model IS
    'CCTV device model.';

COMMENT ON COLUMN cctv_devices.firmware_version IS
    'Installed firmware version.';

COMMENT ON COLUMN cctv_devices.status IS
    'Operational status: active, inactive, or maintenance.';

COMMENT ON COLUMN cctv_devices.latitude IS
    'Latitude in decimal degrees, from -90 to 90.';

COMMENT ON COLUMN cctv_devices.longitude IS
    'Longitude in decimal degrees, from -180 to 180.';

COMMENT ON COLUMN cctv_devices.last_seen_at IS
    'Timestamp when the device was last observed, including time zone.';
