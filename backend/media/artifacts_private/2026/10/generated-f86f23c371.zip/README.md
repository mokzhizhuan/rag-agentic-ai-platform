# CCTV Monitoring Dashboard

A responsive, static CCTV monitoring dashboard built with vanilla HTML, CSS, and JavaScript. It displays camera status, locations, last-seen information, and filtering controls without requiring a framework, build process, server API, or package manager.

## Features

- Responsive dashboard layout for desktop, tablet, and mobile screens
- Four sample CCTV cameras
- Online, offline, and total camera summary counts
- Search cameras by name or location
- Filter cameras by:
  - All statuses
  - Online
  - Offline
- Camera cards with:
  - Camera name
  - Location
  - Status badge
  - Camera ID
  - Last-seen value
  - Stream link for online cameras
- Empty state when no cameras match the selected search or filter
- Semantic HTML and accessible labels
- Visible keyboard focus states
- No external frameworks or runtime dependencies

## Project structure

- `index.html` — Main dashboard page and semantic application structure
- `styles.css` — Responsive layout, colors, cards, controls, status indicators, and mobile styles
- `app.js` — Sample camera data, rendering logic, filtering, searching, and summary counters
- `README.md` — Project documentation

## Opening the project locally

No build step or local server is required.

1. Place all project files in the same directory.
2. Open `index.html` directly in a modern web browser.

The HTML file references the local assets using relative paths:

- `styles.css`
- `app.js`

The JavaScript is loaded with `defer`, so it runs after the document has been parsed.

## Sample camera data

The dashboard defines four sample camera records in `app.js`. Each record contains the following fields:

| Field | Description |
| --- | --- |
| `id` | Unique camera identifier |
| `name` | Display name of the camera |
| `location` | Building, campus, or area where the camera is located |
| `status` | Camera availability; must be exactly `online` or `offline` |
| `streamUrl` | Relative or placeholder URL for an online stream |
| `thumbnail` | Local thumbnail path or an empty value when no preview is available |
| `lastSeen` | Human-readable time indicating when the camera was last detected |

The included sample cameras are:

- Main Entrance — North Building — Online
- Parking Lot — East Campus — Online
- Warehouse Interior — South Building — Offline
- Loading Dock — West Campus — Online

The sample stream URLs and thumbnail values are placeholders. Replace them with approved local assets or authorized stream endpoints when integrating real camera systems.

## Filtering behavior

The search field uses the `camera-search` element ID and checks the entered text against each camera's:

- `name`
- `location`

The status selector uses the `status-filter` element ID and supports these values:

- `all`
- `online`
- `offline`

Search and status filtering can be used together. Results are rendered inside the `camera-grid` element. If no cameras match, the `empty-state` element becomes visible.

Summary counters always represent the complete sample camera set:

- `online-count`
- `offline-count`
- `total-count`

## DOM contract

The JavaScript expects these IDs to be present in `index.html`:

- `camera-search`
- `status-filter`
- `camera-grid`
- `empty-state`
- `online-count`
- `offline-count`
- `total-count`

Do not rename these IDs unless the corresponding references in `app.js` are updated as well.

## Accessibility notes

- The page uses semantic headings, sections, articles, labels, and links.
- Search and status controls have accessible labels.
- Camera results use an `aria-live` region so updates can be announced by assistive technologies.
- Decorative icons are hidden from assistive technology where appropriate.
- Keyboard focus indicators are provided for interactive controls.
- Offline stream links are marked unavailable and cannot be activated.

## Browser behavior

The project is intended for current versions of major browsers, including:

- Chrome
- Edge
- Firefox
- Safari

It uses standard HTML, CSS, and JavaScript APIs and does not require a browser extension, transpiler, package manager, API route, secret, or server-side runtime.
