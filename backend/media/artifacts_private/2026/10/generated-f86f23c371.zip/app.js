const cameras = [
  {
    id: "cam-001",
    name: "Main Entrance",
    location: "North Building",
    status: "online",
    streamUrl: "#",
    thumbnail: "",
    lastSeen: "Just now"
  },
  {
    id: "cam-002",
    name: "Parking Lot",
    location: "East Campus",
    status: "online",
    streamUrl: "#",
    thumbnail: "",
    lastSeen: "Just now"
  },
  {
    id: "cam-003",
    name: "Warehouse Interior",
    location: "South Building",
    status: "offline",
    streamUrl: "#",
    thumbnail: "",
    lastSeen: "12 minutes ago"
  },
  {
    id: "cam-004",
    name: "Loading Dock",
    location: "West Campus",
    status: "online",
    streamUrl: "#",
    thumbnail: "",
    lastSeen: "Just now"
  }
];

const elements = {
  search: document.getElementById("camera-search"),
  statusFilter: document.getElementById("status-filter"),
  cameraGrid: document.getElementById("camera-grid"),
  emptyState: document.getElementById("empty-state"),
  onlineCount: document.getElementById("online-count"),
  offlineCount: document.getElementById("offline-count"),
  totalCount: document.getElementById("total-count")
};

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function getFilteredCameras() {
  const query = elements.search.value.trim().toLowerCase();
  const selectedStatus = elements.statusFilter.value;

  return cameras.filter((camera) => {
    const matchesSearch =
      !query ||
      camera.name.toLowerCase().includes(query) ||
      camera.location.toLowerCase().includes(query);

    const matchesStatus =
      selectedStatus === "all" || camera.status === selectedStatus;

    return matchesSearch && matchesStatus;
  });
}

function cameraPreview(camera) {
  if (camera.thumbnail) {
    return `
      <img
        class="camera-thumbnail"
        src="${escapeHtml(camera.thumbnail)}"
        alt="${escapeHtml(camera.name)} live preview"
        loading="lazy"
      >
    `;
  }

  return `
    <div class="camera-thumbnail camera-thumbnail--placeholder" aria-label="No preview available">
      <span class="camera-placeholder-icon" aria-hidden="true">◉</span>
      <span>Preview unavailable</span>
    </div>
  `;
}

function renderCameraCard(camera) {
  const isOnline = camera.status === "online";
  const statusLabel = isOnline ? "Online" : "Offline";

  return `
    <article class="camera-card">
      <div class="camera-preview">
        ${cameraPreview(camera)}
        <span class="status-badge status-badge--${escapeHtml(camera.status)}">
          <span class="status-dot" aria-hidden="true"></span>
          ${statusLabel}
        </span>
      </div>

      <div class="camera-card-body">
        <div class="camera-card-heading">
          <div>
            <h3>${escapeHtml(camera.name)}</h3>
            <p class="camera-location">${escapeHtml(camera.location)}</p>
          </div>
          <span class="camera-id">${escapeHtml(camera.id)}</span>
        </div>

        <div class="camera-card-footer">
          <span class="last-seen">
            <span class="last-seen-label">Last seen</span>
            <strong>${escapeHtml(camera.lastSeen)}</strong>
          </span>
          <a
            class="camera-action${isOnline ? "" : " camera-action--disabled"}"
            href="${isOnline ? escapeHtml(camera.streamUrl) : "#"}"
            ${isOnline ? "" : 'aria-disabled="true" tabindex="-1"'}
          >
            ${isOnline ? "View stream" : "Unavailable"}
          </a>
        </div>
      </div>
    </article>
  `;
}

function updateSummary() {
  const onlineCameras = cameras.filter((camera) => camera.status === "online");
  const offlineCameras = cameras.filter((camera) => camera.status === "offline");

  elements.onlineCount.textContent = onlineCameras.length;
  elements.offlineCount.textContent = offlineCameras.length;
  elements.totalCount.textContent = cameras.length;
}

function renderCameras() {
  const filteredCameras = getFilteredCameras();

  elements.cameraGrid.innerHTML = filteredCameras
    .map(renderCameraCard)
    .join("");

  elements.emptyState.hidden = filteredCameras.length !== 0;
  elements.cameraGrid.hidden = filteredCameras.length === 0;
}

function renderDashboard() {
  updateSummary();
  renderCameras();
}

elements.search.addEventListener("input", renderCameras);
elements.statusFilter.addEventListener("change", renderCameras);

elements.cameraGrid.addEventListener("click", (event) => {
  const disabledAction = event.target.closest(".camera-action--disabled");

  if (disabledAction) {
    event.preventDefault();
  }
});

renderDashboard();
