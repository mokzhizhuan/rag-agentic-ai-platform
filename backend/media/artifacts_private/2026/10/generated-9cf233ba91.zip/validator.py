import argparse
import csv
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import yaml


CANONICAL_FIELDS = [
    "device_id",
    "camera_name",
    "location",
    "rtsp_url",
    "enabled",
    "retention_days",
    "last_seen_at",
]

BOOLEAN_VALUES = {"true": True, "false": False}
INTEGER_PATTERN = re.compile(r"^[0-9]+$")


def error(message: str) -> None:
    print(f"Validation error: {message}", file=sys.stderr)


def load_config(config_path: Path) -> dict:
    try:
        with config_path.open("r", encoding="utf-8") as config_file:
            config = yaml.safe_load(config_file)
    except FileNotFoundError:
        raise ValueError(f"configuration file not found: {config_path}")
    except OSError as exc:
        raise ValueError(f"unable to read configuration file {config_path}: {exc}")
    except yaml.YAMLError as exc:
        raise ValueError(f"invalid YAML in {config_path}: {exc}")

    if not isinstance(config, dict):
        raise ValueError("configuration must contain a YAML mapping")

    required_columns = config.get("required_columns")
    if required_columns != CANONICAL_FIELDS:
        raise ValueError(
            "required_columns must match the canonical field list exactly"
        )

    minimum = config.get("retention_days_min")
    maximum = config.get("retention_days_max")
    if not isinstance(minimum, int) or not isinstance(maximum, int):
        raise ValueError("retention_days_min and retention_days_max must be integers")
    if minimum != 1 or maximum != 365 or minimum > maximum:
        raise ValueError(
            "retention_days_min and retention_days_max must be 1 and 365"
        )

    input_csv = config.get("input_csv")
    if not isinstance(input_csv, str) or not input_csv.strip():
        raise ValueError("input_csv must be a non-empty string")

    return config


def validate_rtsp_url(value: str) -> bool:
    try:
        parsed = urlsplit(value)
    except ValueError:
        return False
    return (
        parsed.scheme.lower() == "rtsp"
        and bool(parsed.netloc)
        and bool(parsed.hostname)
    )


def validate_timestamp(value: str) -> bool:
    if not value:
        return True

    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        timestamp = datetime.fromisoformat(normalized)
    except ValueError:
        return False

    if timestamp.tzinfo is None:
        return False

    return timestamp.astimezone(timezone.utc).utcoffset() == timezone.utc.utcoffset(
        timestamp
    )


def validate_record(row: dict, line_number: int, minimum: int, maximum: int) -> list[str]:
    errors = []

    for field in CANONICAL_FIELDS:
        value = row.get(field)
        if value is None:
            errors.append(f"line {line_number}: missing field '{field}'")

    if errors:
        return errors

    text_values = ("device_id", "camera_name", "location", "rtsp_url")
    for field in text_values:
        if not row[field].strip():
            errors.append(f"line {line_number}: '{field}' must not be empty")

    if not validate_rtsp_url(row["rtsp_url"].strip()):
        errors.append(
            f"line {line_number}: 'rtsp_url' must be a valid RTSP URL"
        )

    enabled_value = row["enabled"].strip().lower()
    if enabled_value not in BOOLEAN_VALUES:
        errors.append(
            f"line {line_number}: 'enabled' must be 'true' or 'false'"
        )

    retention_value = row["retention_days"].strip()
    if not INTEGER_PATTERN.fullmatch(retention_value):
        errors.append(
            f"line {line_number}: 'retention_days' must be an integer"
        )
    else:
        retention_days = int(retention_value)
        if not minimum <= retention_days <= maximum:
            errors.append(
                f"line {line_number}: 'retention_days' must be between "
                f"{minimum} and {maximum}"
            )

    if not validate_timestamp(row["last_seen_at"].strip()):
        errors.append(
            f"line {line_number}: 'last_seen_at' must be a nullable ISO 8601 UTC timestamp"
        )

    return errors


def validate_csv(input_path: Path, config: dict) -> int:
    minimum = config["retention_days_min"]
    maximum = config["retention_days_max"]
    seen_device_ids: set[str] = set()

    try:
        csv_file = input_path.open("r", encoding="utf-8", newline="")
    except FileNotFoundError:
        error(f"input CSV not found: {input_path}")
        return 1
    except OSError as exc:
        error(f"unable to read input CSV {input_path}: {exc}")
        return 1

    with csv_file:
        reader = csv.DictReader(csv_file)

        if reader.fieldnames is None:
            error("input CSV is missing a header row")
            return 1

        headers = reader.fieldnames
        if len(headers) != len(set(headers)):
            error("input CSV contains duplicate column names")
            return 1

        if set(headers) != set(CANONICAL_FIELDS):
            missing = sorted(set(CANONICAL_FIELDS) - set(headers))
            unexpected = sorted(set(headers) - set(CANONICAL_FIELDS))
            if missing:
                error(f"input CSV is missing columns: {', '.join(missing)}")
            if unexpected:
                error(f"input CSV contains unexpected columns: {', '.join(unexpected)}")
            return 1

        has_errors = False
        record_count = 0

        for line_number, row in enumerate(reader, start=2):
            record_count += 1
            if None in row:
                error(f"line {line_number}: row has more values than the header")
                has_errors = True
                continue

            device_id = (row.get("device_id") or "").strip()
            if device_id in seen_device_ids:
                error(f"line {line_number}: duplicate device_id '{device_id}'")
                has_errors = True
            elif device_id:
                seen_device_ids.add(device_id)

            for message in validate_record(row, line_number, minimum, maximum):
                error(message)
                has_errors = True

        if record_count == 0:
            error("input CSV contains no records")
            has_errors = True

    return 1 if has_errors else 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate CCTV device records from a CSV file."
    )
    parser.add_argument("--input", required=True, help="path to the input CSV file")
    parser.add_argument(
        "--config", required=True, help="path to the YAML settings file"
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        config = load_config(Path(args.config))
    except ValueError as exc:
        error(str(exc))
        return 1

    return validate_csv(Path(args.input), config)


if __name__ == "__main__":
    sys.exit(main())
