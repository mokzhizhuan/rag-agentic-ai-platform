# CCTV Device Record Validator

A file-based data-processing project for validating CCTV device records stored in CSV format. The validator uses Python 3.11 or newer, YAML configuration, and the Python standard library plus PyYAML. No database connection is required for validation.

## Project files

- `validator.py` — Command-line CSV validator.
- `settings.yaml` — Non-secret validation settings and canonical column definitions.
- `data/sample_cctv_devices.csv` — Valid sample CCTV records.
- `schema.sql` — PostgreSQL table definition.
- `requirements.txt` — Python runtime dependency declaration.
- `.env.example` — Safe template for future PostgreSQL connection variables.

## Requirements

- Python 3.11 or newer
- PostgreSQL, only if deploying the database schema
- `pip` for installing the YAML dependency

## Installation

Create and activate a virtual environment, then install the dependency:

    python3 -m venv .venv
    . .venv/bin/activate
    python -m pip install -r requirements.txt

On Windows PowerShell, activate the environment with:

    .venv\Scripts\Activate.ps1

## Validate the sample data

Run the validator from the project root:

    python validator.py --input data/sample_cctv_devices.csv --config settings.yaml

A successful validation exits with status `0` and produces no validation errors. Invalid input, invalid configuration, missing files, or an unexpected CSV structure exits with status `1`. Validation errors are written to standard error.

The `--input` argument selects the CSV file to validate. The `input_csv` setting in `settings.yaml` documents the sample input path; the input path is still supplied explicitly on the command line.

## CSV field contract

The CSV header must contain exactly these fields:

1. `device_id`
2. `camera_name`
3. `location`
4. `rtsp_url`
5. `enabled`
6. `retention_days`
7. `last_seen_at`

Field rules:

- `device_id` — Non-empty string and unique within the CSV file.
- `camera_name` — Non-empty string.
- `location` — Non-empty string.
- `rtsp_url` — Non-empty URL using the `rtsp` scheme with a valid host.
- `enabled` — Must be `true` or `false`, case-insensitively.
- `retention_days` — Integer from `1` through `365`, inclusive.
- `last_seen_at` — Empty for a nullable value, or an ISO 8601 timestamp containing a UTC offset. A trailing `Z` is accepted for UTC timestamps.

CSV records must include values for every canonical field. Duplicate headers, missing headers, unexpected headers, empty files, duplicate device IDs, and rows with extra values are rejected.

## Configuration

`settings.yaml` contains:

- `input_csv: data/sample_cctv_devices.csv`
- The canonical `required_columns` list
- `retention_days_min: 1`
- `retention_days_max: 365`

The validator verifies that the required columns and retention bounds match the project contract. The settings file contains no credentials.

To validate another CSV while using the same settings:

    python validator.py --input path/to/another_devices.csv --config settings.yaml

## PostgreSQL schema

The PostgreSQL schema creates a table named `cctv_devices` with these columns:

- `device_id` — `TEXT PRIMARY KEY`
- `camera_name` — `TEXT NOT NULL`
- `location` — `TEXT NOT NULL`
- `rtsp_url` — `TEXT NOT NULL`
- `enabled` — `BOOLEAN NOT NULL`
- `retention_days` — `INTEGER NOT NULL`, constrained from `1` through `365`
- `last_seen_at` — Nullable `TIMESTAMPTZ`

Load the schema using the PostgreSQL client:

    psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -f schema.sql

The command requires an existing PostgreSQL database and appropriate runtime authentication. The schema deployment is separate from CSV validation, and `validator.py` does not connect to PostgreSQL.

## PostgreSQL environment variables

`.env.example` documents these non-secret connection variable names:

- `POSTGRES_HOST`
- `POSTGRES_PORT`
- `POSTGRES_DB`
- `POSTGRES_USER`
- `POSTGRES_PASSWORD`

Do not commit passwords, tokens, or real credentials. Supply `POSTGRES_PASSWORD` securely through the runtime environment or an approved secret-management system. The project does not require PostgreSQL credentials to validate CSV files.
