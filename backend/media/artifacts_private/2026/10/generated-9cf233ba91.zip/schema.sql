CREATE TABLE IF NOT EXISTS cctv_devices (
    device_id TEXT PRIMARY KEY,
    camera_name TEXT NOT NULL,
    location TEXT NOT NULL,
    rtsp_url TEXT NOT NULL,
    enabled BOOLEAN NOT NULL,
    retention_days INTEGER NOT NULL CHECK (retention_days BETWEEN 1 AND 365),
    last_seen_at TIMESTAMPTZ NULL
);
